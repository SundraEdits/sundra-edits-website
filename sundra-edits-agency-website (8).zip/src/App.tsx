import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Lenis from "lenis";
import { MessageCircle } from "lucide-react";
import Loader from "./components/Loader";
import Cursor from "./components/Cursor";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import About from "./components/About";
import Services from "./components/Services";
import Work from "./components/Work";
import Process from "./components/Process";
import WhyUs from "./components/WhyUs";
import Contact from "./components/Contact";
import { CONTACT } from "./data/content";
import { lockScroll, scrollToId, setLenis, unlockScroll } from "./lib/scroll";

function FloatingWhatsApp({ visible }: { visible: boolean }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.a
          href={CONTACT.whatsappLink}
          target="_blank"
          rel="noreferrer"
          className="group fixed bottom-6 right-6 z-[70] flex items-center gap-0 rounded-full bg-[#25d366] text-white shadow-[0_18px_40px_-10px_rgba(37,211,102,0.65)] transition-all duration-300 hover:pr-6 sm:bottom-8 sm:right-8"
          initial={{ opacity: 0, scale: 0.5, y: 24 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.5, y: 24 }}
          transition={{ type: "spring", stiffness: 260, damping: 20 }}
          aria-label="Chat with SUNDRA EDITS on WhatsApp"
          data-hover
        >
          <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-[#25d366]/40 [animation-duration:2.4s]" />
          <span className="flex h-14 w-14 items-center justify-center">
            <MessageCircle className="h-6 w-6 fill-current" />
          </span>
          <span className="max-w-0 overflow-hidden whitespace-nowrap text-[11px] font-extrabold uppercase tracking-[0.2em] opacity-0 transition-all duration-500 group-hover:max-w-[140px] group-hover:opacity-100">
            Chat with us
          </span>
        </motion.a>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  const [loading, setLoading] = useState(true);
  const [showWhatsApp, setShowWhatsApp] = useState(false);
  const [enquiryService, setEnquiryService] = useState<string>("Video Editing");

  /* Service CTAs pre-select the enquiry form, then travel to it */
  const chooseService = useCallback((service: string) => {
    setEnquiryService(service);
    scrollToId("contact");
  }, []);

  /* Lenis buttery smooth scrolling */
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.15,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      touchMultiplier: 1.4,
    });
    setLenis(lenis);
    let raf: number;
    const loop = (time: number) => {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      setLenis(null);
    };
  }, []);

  /* lock scroll during the loader */
  useEffect(() => {
    if (loading) lockScroll();
    else unlockScroll();
  }, [loading]);

  /* floating WhatsApp appears after the hero */
  useEffect(() => {
    const onScroll = () => setShowWhatsApp(window.scrollY > window.innerHeight * 0.75);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const finishLoading = useCallback(() => setLoading(false), []);

  return (
    <div className="relative min-h-screen bg-cream text-charcoal">
      <AnimatePresence>{loading && <Loader onComplete={finishLoading} />}</AnimatePresence>

      <Cursor />
      <Navbar started={!loading} />

      <main>
        <Hero active={!loading} />
        <Marquee />
        <About />
        <Services onEnquire={chooseService} />
        <Work />
        <Process />
        <WhyUs />
        <Contact service={enquiryService} onServiceChange={setEnquiryService} />
      </main>

      <FloatingWhatsApp visible={!loading && showWhatsApp} />
    </div>
  );
}
