import {
  Bot,
  Clapperboard,
  Code2,
  Focus,
  Layers,
  Lightbulb,
  Share2,
  Target,
  type LucideIcon,
} from "lucide-react";

/* ============================================================
   SUNDRA EDITS — SITE CONTENT
   ✎  EDIT PORTFOLIO VIDEO LINKS in the PROJECTS section below.
   Paste a Google Drive "/preview" embed link as videoUrl and
   the built-in player picks it up automatically.
   ============================================================ */

import tulipThumb from "../assets/tulip-fashion.jpg";
import apnaThumb from "../assets/apna-mens-wear.jpg";
import aboutImg from "../assets/studio.jpg";

export const ABOUT_IMAGE = aboutImg;

/* ————————————————— BRAND & CONTACT ————————————————— */
export const CONTACT = {
  whatsappDisplay: "+91 93343 09446",
  whatsappLink:
    "https://wa.me/919334309446?text=Hello%20SUNDRA%20EDITS!%20I%27d%20love%20to%20discuss%20a%20creative%20project.",
  whatsappPlain: "https://wa.me/919334309446",
  email: "sundraedits@gmail.com",
  emailLink: "mailto:sundraedits@gmail.com",
  websiteDisplay: "sundraedits.in",
  websiteLink: "https://sundraedits.in",
  location: "Kanti, Muzaffarpur, Bihar — 843109, India",
  locationShort: "Kanti, Muzaffarpur, Bihar, India",
};

/* ————————————————— SOCIAL PROFILES ————————————————— */
export type SocialIconName = "instagram" | "facebook" | "youtube" | "linkedin" | "pinterest";

export const SOCIALS: { label: string; href: string; icon: SocialIconName }[] = [
  {
    label: "Instagram",
    href: "https://www.instagram.com/sundra.edits?evlk=aHRjdXV4eHNodDhx",
    icon: "instagram",
  },
  {
    label: "Facebook",
    href: "https://www.facebook.com/share/1CtyfmUzRY/",
    icon: "facebook",
  },
  {
    label: "YouTube",
    href: "https://youtube.com/@sundraedits?si=7qCHRpb_7NQeVjsj",
    icon: "youtube",
  },
  {
    label: "LinkedIn",
    href: "https://www.linkedin.com/in/sundra-edits-783053451?trk=contact-info",
    icon: "linkedin",
  },
  {
    label: "Pinterest",
    href: "https://pin.it/6SWh29FWj",
    icon: "pinterest",
  },
];

/* ————————————————— NAVIGATION ————————————————— */
export const NAV_LINKS = [
  { label: "Home", id: "home" },
  { label: "About", id: "about" },
  { label: "Services", id: "services" },
  { label: "Portfolio", id: "portfolio" },
  { label: "Process", id: "process" },
  { label: "Contact", id: "contact" },
] as const;

/* ————————————————— PORTFOLIO ————————————————— */
export interface Project {
  id: string;
  index: string;
  brand: string;
  category: string;
  role: string;
  description: string;
  thumbnail: string;
  /** Google Drive embed link — editable */
  videoUrl: string;
}

export const PROJECTS: Project[] = [
  {
    id: "tulip-fashion",
    index: "01",
    brand: "TULIP FASHION",
    category: "Fashion Retail — Brand Film",
    role: "Promotional Video",
    description:
      "A luminous storefront story for a women's fashion destination — colour, craft and celebration, edited into a film that feels like walking through the boutique itself.",
    thumbnail: tulipThumb,
    videoUrl:
      "https://drive.google.com/file/d/14OOHpnmMAaVV6ZCdIVyDCYHrAluyEDVn/preview",
  },
  {
    id: "apna-mens-wear",
    index: "02",
    brand: "APNA MEN'S WEAR",
    category: "Menswear Retail — Brand Film",
    role: "Promotional Video",
    description:
      "Style, comfort and confidence — a bold, high-energy showcase for a modern menswear destination, cut to hold attention from the first frame to the last.",
    thumbnail: apnaThumb,
    videoUrl:
      "https://drive.google.com/file/d/13XlCbyM-QEOWYxg3u0UDGmE-VzuUy4Bl/preview",
  },
];

/* ————————————————— SERVICE DEPARTMENTS ————————————————— */
export interface ServiceDepartment {
  index: string;
  icon: LucideIcon;
  title: string;
  positioning: string;
  items: string[];
  /** Value pre-selected in the enquiry form dropdown */
  enquiryValue: string;
  note?: string;
}

export const SERVICE_DEPARTMENTS: ServiceDepartment[] = [
  {
    index: "01",
    icon: Clapperboard,
    title: "Video Editing & Creative Production",
    positioning:
      "We transform ordinary footage and creative ideas into polished, engaging and brand-focused video content.",
    items: [
      "Instagram Reels & YouTube Shorts",
      "Promotional Videos",
      "AI Advertisement Videos",
      "Brand Videos",
      "Product & Business Promotional Content",
      "Raw Footage to Professional Video Editing",
    ],
    enquiryValue: "Video Editing",
  },
  {
    index: "02",
    icon: Share2,
    title: "Social Media Management",
    positioning:
      "We help businesses maintain a consistent, professional and engaging social media presence — planned, published and managed for you.",
    items: [
      "Complete Social Media Account Management",
      "Content Planning",
      "Content Strategy",
      "Post & Reel Publishing",
      "Account Growth Strategy",
      "Brand Consistency",
      "Content Calendar Management",
    ],
    enquiryValue: "Social Media Management",
  },
  {
    index: "03",
    icon: Code2,
    title: "Website Development",
    positioning:
      "We create modern digital storefronts that help businesses present their products and services professionally.",
    items: [
      "Professional Business Websites",
      "Product & Service Showcases",
      "Image Galleries",
      "Business Location & Contact Details",
      "WhatsApp Enquiry Integration",
      "Mobile-Friendly Design",
    ],
    enquiryValue: "Website Development",
    note: "Made for local shops, restaurants, boutiques, furniture stores & growing businesses.",
  },
];

export const ENQUIRY_SERVICES = [
  "Video Editing",
  "AI Advertisement",
  "Social Media Management",
  "Website Development",
  "Other",
] as const;

/* ————————————————— PROCESS ————————————————— */
export const PROCESS_STEPS = [
  {
    title: "DISCOVER",
    description:
      "We understand your business, your audience and exactly what the project needs to achieve.",
  },
  {
    title: "CREATE",
    description:
      "The creative concept takes shape — edits, designs and content developed around your brand.",
  },
  {
    title: "REFINE",
    description:
      "We review the work together and improve every detail until it feels right.",
  },
  {
    title: "DELIVER",
    description:
      "The approved final project — finished, polished and ready to publish.",
  },
];

/* ————————————————— WHY SUNDRA EDITS ————————————————— */
export interface WhyItem {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const WHY_ITEMS: WhyItem[] = [
  {
    icon: Lightbulb,
    title: "Creative-First Approach",
    description:
      "Every project starts with an original idea shaped around your brand — never a recycled template.",
  },
  {
    icon: Layers,
    title: "Professional Presentation",
    description:
      "Your business is presented with the polish and consistency your customers expect from a brand they trust.",
  },
  {
    icon: Bot,
    title: "Modern AI-Powered Workflows",
    description:
      "Human taste, amplified by today's best AI tools — ambitious ideas become possible at any scale.",
  },
  {
    icon: Target,
    title: "Business-Focused Solutions",
    description:
      "We think like partners, not vendors. Every decision serves your goals, your audience and your growth.",
  },
  {
    icon: Focus,
    title: "Attention to Detail",
    description:
      "Cuts timed to the beat, frames graded by hand, layouts refined pixel by pixel. Details are our signature.",
  },
  {
    icon: Share2,
    title: "Video, Social & Web — One Roof",
    description:
      "One creative partner across video, social media and websites, so your brand speaks with a single voice.",
  },
];

export const MARQUEE_ITEMS = [
  "Video Editing",
  "AI Advertising",
  "Social Media",
  "Web Development",
  "Brand Videos",
  "Reels & Shorts",
];
