import { motion } from "framer-motion";
import type { ReactNode } from "react";

export const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];

/* ——— Fade-and-rise reveal on scroll ——— */
export function FadeUp({
  children,
  delay = 0,
  y = 32,
  className,
  once = true,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  once?: boolean;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: "-70px" }}
      transition={{ duration: 0.85, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

/* ——— Editorial section label:  01 ——— LABEL ———— ——— */
export function SectionTag({
  index,
  label,
  dark = false,
  className = "",
}: {
  index: string;
  label: string;
  dark?: boolean;
  className?: string;
}) {
  return (
    <FadeUp y={16}>
      <div className={`flex items-center gap-4 ${className}`}>
        <span
          className={`font-display text-sm tracking-widest ${
            dark ? "text-champagne" : "text-champagne-dark"
          }`}
        >
          {index}
        </span>
        <span
          className={`h-px w-10 ${dark ? "bg-champagne/60" : "bg-champagne-dark/50"}`}
        />
        <span
          className={`text-[11px] font-bold uppercase tracking-[0.38em] ${
            dark ? "text-cream/70" : "text-charcoal/60"
          }`}
        >
          {label}
        </span>
        <span
          className={`h-px flex-1 ${dark ? "bg-cream/12" : "bg-charcoal/10"}`}
        />
      </div>
    </FadeUp>
  );
}

/* ——— Word-by-word masked reveal, used for statement typography ——— */
export function WordReveal({
  text,
  className = "",
  wordClassName = "",
  delay = 0,
}: {
  text: string;
  className?: string;
  wordClassName?: string;
  delay?: number;
}) {
  const words = text.split(" ");
  return (
    <span className={className} aria-label={text}>
      {words.map((word, i) => (
        <span
          key={i}
          className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-bottom"
          aria-hidden
        >
          <motion.span
            className={`inline-block will-change-transform ${wordClassName}`}
            initial={{ y: "110%" }}
            whileInView={{ y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.7, delay: delay + i * 0.028, ease: EASE }}
          >
            {word}
            {i < words.length - 1 ? "\u00A0" : ""}
          </motion.span>
        </span>
      ))}
    </span>
  );
}
