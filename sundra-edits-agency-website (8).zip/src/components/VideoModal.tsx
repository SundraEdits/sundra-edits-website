import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ExternalLink, Loader2, X } from "lucide-react";
import type { Project } from "../data/content";
import { lockScroll, unlockScroll } from "../lib/scroll";
import { EASE } from "./Reveal";

/**
 * Premium modal video player (Google Drive embed).
 * Shows a loading state until the player is ready, and always
 * offers a graceful "Open in Google Drive" fallback.
 */
export default function VideoModal({
  project,
  onClose,
}: {
  project: Project;
  onClose: () => void;
}) {
  const [loaded, setLoaded] = useState(false);
  const viewUrl = project.videoUrl.replace("/preview", "/view");

  useEffect(() => {
    lockScroll();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      unlockScroll();
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <motion.div
      className="fixed inset-0 z-[95] flex items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`${project.brand} video player`}
    >
      <motion.div
        className="absolute inset-0 bg-charcoal/95 backdrop-blur-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      />
      <motion.div
        className="relative w-full max-w-5xl overflow-hidden rounded-2xl border border-cream/12 bg-espresso shadow-[0_60px_120px_-30px_rgba(0,0,0,0.9)]"
        initial={{ opacity: 0, y: 60, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 40, scale: 0.97 }}
        transition={{ duration: 0.55, ease: EASE }}
      >
        {/* header */}
        <div className="flex items-center justify-between gap-4 px-5 py-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-champagne font-display text-xs font-black text-charcoal">
              {project.index}
            </span>
            <div className="min-w-0">
              <p className="truncate font-display text-base font-extrabold uppercase tracking-[0.04em] text-cream sm:text-lg">
                {project.brand}
              </p>
              <p className="truncate text-[9px] font-extrabold uppercase tracking-[0.28em] text-champagne-light/80">
                {project.category}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-cream/20 text-cream transition-all duration-300 hover:rotate-90 hover:border-champagne hover:bg-champagne hover:text-charcoal"
            aria-label="Close video"
            data-hover
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* player */}
        <div className="relative aspect-video w-full bg-black">
          {!loaded && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-cream/60">
              <Loader2 className="h-8 w-8 animate-spin text-champagne" />
              <p className="text-[10px] font-extrabold uppercase tracking-[0.3em]">
                Loading the film…
              </p>
            </div>
          )}
          <iframe
            key={project.id}
            src={project.videoUrl}
            title={`${project.brand} — promotional film by SUNDRA EDITS`}
            className={`absolute inset-0 h-full w-full transition-opacity duration-700 ${
              loaded ? "opacity-100" : "opacity-0"
            }`}
            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
            allowFullScreen
            loading="eager"
            onLoad={() => setLoaded(true)}
          />
        </div>

        {/* footer — graceful fallback */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 sm:px-6">
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.25em] text-cream/50">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-champagne" />
            Now playing — streamed via Google Drive
          </p>
          <a
            href={viewUrl}
            target="_blank"
            rel="noreferrer"
            className="group flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.25em] text-champagne-light transition-colors hover:text-cream"
            data-hover
          >
            Open in Drive
            <ExternalLink className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </a>
        </div>
      </motion.div>
    </motion.div>
  );
}
