import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, MessageCircle, X } from "lucide-react";
import { CONTACT, NAV_LINKS } from "../data/content";
import { lockScroll, scrollToId, scrollToTop, unlockScroll } from "../lib/scroll";
import { EASE } from "./Reveal";

export default function Navbar({ started }: { started: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (open) lockScroll();
    else unlockScroll();
  }, [open ]);

  const go = (id: string) => {
    setOpen(false);
    // wait for the menu exit before travelling
    setTimeout(() => scrollToId(id), open ? 350 : 0);
  };

  return (
    <>
      <motion.header
        className={`fixed inset-x-0 top-0 z-[80] transition-all duration-500 ${
          open
            ? "border-b border-transparent bg-transparent"
            : scrolled
              ? "border-b border-charcoal/8 bg-cream/85 shadow-[0_10px_40px_-18px_rgba(59,47,47,0.35)] backdrop-blur-xl"
              : "border-b border-transparent bg-transparent"
        }`}
        initial={{ y: -80, opacity: 0 }}
        animate={started ? { y: 0, opacity: 1 } : {}}
        transition={{ duration: 0.9, delay: 0.15, ease: EASE }}
      >
        <div className="wrap flex h-[72px] items-center justify-between sm:h-20">
          {/* Logo */}
          <button
            onClick={() => (open ? setOpen(false) : scrollToTop())}
            className="group flex items-baseline gap-1.5"
            aria-label="SUNDRA EDITS — back to top"
            data-hover
          >
            <span
              className={`font-display text-[22px] font-black tracking-[0.03em] transition-colors sm:text-2xl ${
                open ? "text-cream" : "text-charcoal group-hover:text-espresso"
              }`}
            >
              SUNDRA
            </span>
            <span
              className={`font-display text-[22px] font-black tracking-[0.03em] sm:text-2xl ${
                open ? "text-champagne" : "text-champagne-dark"
              }`}
            >
              EDITS
            </span>
            <span className={`mb-auto text-[9px] font-bold ${open ? "text-cream/50" : "text-charcoal/50"}`}>®</span>
          </button>

          {/* Desktop links */}
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
            {NAV_LINKS.map((link, i) => (
              <button
                key={link.id}
                onClick={() => go(link.id)}
                className="group relative py-2 text-[12px] font-bold uppercase tracking-[0.22em] text-charcoal/70 transition-colors hover:text-charcoal"
                data-hover
              >
                <span className="mr-1 align-super text-[8px] font-extrabold text-champagne-dark">
                  0{i + 1}
                </span>
                {link.label}
                <span className="absolute inset-x-0 -bottom-0.5 h-px origin-left scale-x-0 bg-champagne-dark transition-transform duration-500 ease-out group-hover:scale-x-100" />
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href={CONTACT.whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="group relative hidden items-center gap-2.5 overflow-hidden rounded-full bg-charcoal px-6 py-3 text-[11px] font-bold uppercase tracking-[0.22em] text-cream transition-transform duration-300 hover:scale-[1.03] active:scale-95 sm:flex"
              data-hover
            >
              <span className="absolute inset-0 -translate-x-full bg-[#25d366] transition-transform duration-500 ease-out group-hover:translate-x-0" />
              <MessageCircle className="relative h-4 w-4 fill-current" />
              <span className="relative">Let's Talk</span>
            </a>

            {/* Mobile toggle */}
            <button
              onClick={() => setOpen((v) => !v)}
              className={`flex h-11 w-11 items-center justify-center rounded-full border transition-colors lg:hidden ${
                open
                  ? "border-cream/30 text-cream hover:border-champagne"
                  : "border-charcoal/15 text-charcoal hover:border-champagne-dark"
              }`}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              data-hover
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* ——— Full-screen mobile menu ——— */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="grain fixed inset-0 z-[75] flex flex-col overflow-hidden bg-espresso text-cream lg:hidden"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.65, ease: [0.76, 0, 0.24, 1] }}
          >
            <div className="pointer-events-none absolute -right-24 top-24 h-72 w-72 rounded-full bg-champagne/15 blur-[100px]" />

            <div className="wrap flex flex-1 flex-col justify-center pt-24">
              <p className="mb-8 text-[10px] font-bold uppercase tracking-[0.4em] text-champagne-light/70">
                Menu — SUNDRA EDITS
              </p>
              <nav className="flex flex-col" aria-label="Mobile">
                {NAV_LINKS.map((link, i) => (
                  <div key={link.id} className="overflow-hidden border-b border-cream/10">
                    <motion.button
                      className="group flex w-full items-center justify-between py-4 text-left"
                      initial={{ y: "110%" }}
                      animate={{ y: 0 }}
                      exit={{ y: "110%", transition: { duration: 0.25 } }}
                      transition={{ duration: 0.6, delay: 0.15 + i * 0.07, ease: EASE }}
                      onClick={() => go(link.id)}
                    >
                      <span className="flex items-baseline gap-4">
                        <span className="font-display text-sm text-champagne">
                          0{i + 1}
                        </span>
                        <span className="font-display text-5xl font-extrabold uppercase leading-none tracking-tight text-cream transition-colors group-active:text-champagne-light sm:text-6xl">
                          {link.label}
                        </span>
                      </span>
                      <ArrowUpRight className="h-7 w-7 text-champagne transition-transform duration-300 group-active:rotate-45" />
                    </motion.button>
                  </div>
                ))}
              </nav>

              <motion.div
                className="mt-10 space-y-2 pb-10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, transition: { duration: 0.2 } }}
                transition={{ duration: 0.6, delay: 0.6, ease: EASE }}
              >
                <p className="font-serif text-xl italic text-champagne-light">
                  Your Vision. Our Creativity.
                </p>
                <a
                  href={CONTACT.whatsappLink}
                  target="_blank"
                  rel="noreferrer"
                  className="block text-sm font-semibold text-cream/80"
                >
                  WhatsApp — {CONTACT.whatsappDisplay}
                </a>
                <a href={CONTACT.emailLink} className="block text-sm font-semibold text-cream/80">
                  {CONTACT.email}
                </a>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
