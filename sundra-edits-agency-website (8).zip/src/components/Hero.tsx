import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, Play } from "lucide-react";
import { PROJECTS, type Project } from "../data/content";
import { scrollToId } from "../lib/scroll";
import VideoModal from "./VideoModal";
import { EASE } from "./Reveal";

function RevealLine({
  children,
  delay,
  active,
  className = "",
}: {
  children: React.ReactNode;
  delay: number;
  active: boolean;
  className?: string;
}) {
  return (
    <span className="block overflow-hidden pb-[0.14em] -mb-[0.14em]">
      <motion.span
        className={`block will-change-transform ${className}`}
        initial={{ y: "112%" }}
        animate={active ? { y: 0 } : {}}
        transition={{ duration: 1.05, delay, ease: EASE }}
      >
        {children}
      </motion.span>
    </span>
  );
}

export default function Hero({ active }: { active: boolean }) {
  const ref = useRef<HTMLElement>(null);
  const [reelIndex, setReelIndex] = useState(0);
  const [playing, setPlaying] = useState<Project | null>(null);

  /* auto-advance the showreel */
  useEffect(() => {
    if (playing) return;
    const t = setInterval(() => setReelIndex((i) => (i + 1) % PROJECTS.length), 5200);
    return () => clearInterval(t);
  }, [playing]);

  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const glowY = useTransform(scrollYProgress, [0, 1], [0, 110]);
  const reelY = useTransform(scrollYProgress, [0, 1], [0, -56]);
  const fade = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  const fadeProps = (delay: number) => ({
    initial: { opacity: 0, y: 26 },
    animate: active ? { opacity: 1, y: 0 } : {},
    transition: { duration: 0.9, delay, ease: EASE },
  });

  const reel = PROJECTS[reelIndex];

  return (
    <section id="home" ref={ref} className="grain relative overflow-hidden bg-cream">
      {/* hairline columns */}
      <div className="pointer-events-none absolute inset-0 mx-auto hidden max-w-[1480px] grid-cols-4 px-12 md:grid" aria-hidden>
        {[...Array(4)].map((_, i) => (
          <div key={i} className="border-l border-charcoal/[0.05] last:border-r" />
        ))}
      </div>
      <motion.div
        className="pointer-events-none absolute -top-32 right-[-10%] h-[520px] w-[520px] rounded-full bg-champagne/20 blur-[140px]"
        style={{ y: glowY }}
        aria-hidden
      />

      <motion.div className="wrap relative pb-20 pt-32 sm:pt-40 lg:pb-24" style={{ opacity: fade }}>
        <div className="grid items-center gap-14 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
          {/* ——— Copy ——— */}
          <div>
            <motion.div {...fadeProps(0.3)} className="mb-7 flex items-center gap-4">
              <span className="h-px w-12 bg-champagne-dark" />
              <span className="text-[10px] font-extrabold uppercase tracking-[0.4em] text-espresso sm:text-[11px]">
                Creative Digital Services — India
              </span>
            </motion.div>

            <h1 className="font-display font-extrabold leading-[1.02] tracking-[-0.02em] text-charcoal">
              <RevealLine delay={0.42} active={active} className="text-[11.5vw] sm:text-6xl lg:text-[4.2rem] xl:text-[5rem]">
                We turn ideas into
              </RevealLine>
              <RevealLine delay={0.55} active={active} className="text-[11.5vw] sm:text-6xl lg:text-[4.2rem] xl:text-[5rem]">
                <span className="font-serif font-medium italic tracking-normal text-champagne-dark">
                  visual experiences.
                </span>
              </RevealLine>
            </h1>

            <motion.p {...fadeProps(0.78)} className="mt-7 max-w-xl text-base font-medium leading-relaxed text-charcoal/65 sm:text-lg">
              SUNDRA EDITS helps brands and businesses grow through premium video editing,
              AI-powered advertising, social media management and modern website development.
            </motion.p>

            <motion.div {...fadeProps(0.92)} className="mt-9 flex flex-wrap items-center gap-4">
              <button
                onClick={() => scrollToId("portfolio")}
                className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full bg-charcoal px-8 py-4 text-[11px] font-extrabold uppercase tracking-[0.22em] text-cream shadow-[0_20px_40px_-16px_rgba(30,30,30,0.5)] transition-transform duration-300 hover:scale-[1.04] active:scale-95"
                data-hover
              >
                <span className="absolute inset-0 -translate-x-[101%] bg-champagne transition-transform duration-500 ease-out group-hover:translate-x-0" />
                <span className="relative transition-colors duration-300 group-hover:text-charcoal">Explore Our Work</span>
                <ArrowDown className="relative h-4 w-4 transition-all duration-300 group-hover:translate-y-0.5 group-hover:text-charcoal" />
              </button>
              <button
                onClick={() => scrollToId("contact")}
                className="group inline-flex items-center gap-2.5 rounded-full border border-charcoal/20 px-8 py-4 text-[11px] font-extrabold uppercase tracking-[0.22em] text-charcoal transition-all duration-300 hover:border-charcoal hover:bg-charcoal hover:text-cream active:scale-95"
                data-hover
              >
                Start a Project
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </motion.div>

            <motion.div {...fadeProps(1.05)} className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-3">
              {["Video Editing", "AI Advertising", "Social Media", "Websites"].map((item) => (
                <span key={item} className="flex items-center gap-2.5 text-[10px] font-extrabold uppercase tracking-[0.26em] text-charcoal/50">
                  <span className="h-1 w-1 rounded-full bg-champagne-dark" />
                  {item}
                </span>
              ))}
            </motion.div>
          </div>

          {/* ——— Cinematic showreel ——— */}
          <motion.div
            initial={{ opacity: 0, y: 56 }}
            animate={active ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1.15, delay: 0.95, ease: EASE }}
          >
            <motion.div style={{ y: reelY }} className="relative">
              {/* frame */}
              <div className="group relative overflow-hidden rounded-[1.6rem] shadow-[0_50px_90px_-35px_rgba(59,47,47,0.55)] ring-1 ring-charcoal/10">
                <button
                  onClick={() => setPlaying(reel)}
                  className="relative block aspect-[4/3] w-full text-left sm:aspect-[16/11]"
                  aria-label={`Watch the ${reel.brand} film`}
                  data-hover
                >
                  <AnimatePresence mode="popLayout">
                    <motion.img
                      key={reel.id}
                      src={reel.thumbnail}
                      alt={`${reel.brand} — featured work by SUNDRA EDITS`}
                      className="absolute inset-0 h-full w-full object-cover"
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 1.4, ease: EASE }}
                    />
                  </AnimatePresence>
                  <span className="absolute inset-0 bg-gradient-to-t from-charcoal/75 via-transparent to-charcoal/25" />

                  {/* top bar */}
                  <span className="absolute inset-x-0 top-0 flex items-center justify-between p-5">
                    <span className="flex items-center gap-2.5 rounded-full border border-cream/25 bg-charcoal/35 px-4 py-2 backdrop-blur-md">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-champagne" />
                      <span className="text-[9px] font-extrabold uppercase tracking-[0.3em] text-cream">
                        Featured Film
                      </span>
                    </span>
                    <span className="font-serif text-base italic text-cream/90">Sundra Edits®</span>
                  </span>

                  {/* play */}
                  <span className="absolute inset-0 flex items-center justify-center">
                    <span className="relative flex h-20 w-20 items-center justify-center">
                      <span className="absolute inset-0 animate-ping rounded-full bg-champagne/35 [animation-duration:2.2s]" />
                      <span className="relative flex h-full w-full items-center justify-center rounded-full border border-cream/30 bg-cream/10 text-cream backdrop-blur-md transition-all duration-500 group-hover:scale-105 group-hover:border-champagne group-hover:bg-champagne group-hover:text-charcoal">
                        <Play className="ml-1 h-6 w-6 fill-current" />
                      </span>
                    </span>
                  </span>

                  {/* bottom caption */}
                  <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 sm:p-6">
                    <span>
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={reel.id}
                          className="block"
                          initial={{ opacity: 0, y: 12 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          transition={{ duration: 0.45, ease: EASE }}
                        >
                          <span className="block text-[9px] font-extrabold uppercase tracking-[0.32em] text-champagne-light">
                            {reel.category}
                          </span>
                          <span className="mt-1 block font-display text-2xl font-extrabold uppercase tracking-[0.02em] text-cream sm:text-3xl">
                            {reel.brand}
                          </span>
                        </motion.span>
                      </AnimatePresence>
                    </span>
                    <span className="mb-1 hidden text-[9px] font-extrabold uppercase tracking-[0.3em] text-cream/70 sm:block">
                      Watch Film
                    </span>
                  </span>
                </button>

                {/* progress segments */}
                <div className="absolute inset-x-5 bottom-2.5 flex gap-2 sm:inset-x-6">
                  {PROJECTS.map((p, i) => (
                    <button
                      key={p.id}
                      onClick={() => setReelIndex(i)}
                      className="group/seg flex-1 py-2"
                      aria-label={`Show ${p.brand}`}
                      data-hover
                    >
                      <span className={`block h-[3px] overflow-hidden rounded-full transition-colors duration-500 ${i === reelIndex ? "bg-cream/25" : "bg-cream/15 group-hover/seg:bg-cream/35"}`}>
                        {i === reelIndex && (
                          <motion.span
                            key={`seg-${reelIndex}`}
                            className="block h-full rounded-full bg-champagne"
                            initial={{ width: "0%" }}
                            animate={{ width: "100%" }}
                            transition={{ duration: 5.2, ease: "linear" }}
                          />
                        )}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* floating tag */}
              <div className="absolute -bottom-6 -left-4 hidden rotate-[-4deg] rounded-2xl bg-charcoal px-5 py-4 text-cream shadow-2xl sm:block lg:-left-8">
                <p className="text-[8.5px] font-extrabold uppercase tracking-[0.3em] text-champagne-light">
                  The Sundra Standard
                </p>
                <p className="mt-1 font-serif text-lg italic leading-none">Your Vision. Our Creativity.</p>
              </div>

              {/* rotating badge */}
              <button
                onClick={() => scrollToId("portfolio")}
                className="group absolute -top-8 right-6 hidden h-24 w-24 items-center justify-center sm:flex"
                aria-label="Explore our portfolio"
                data-hover
              >
                <svg viewBox="0 0 100 100" className="animate-spin-slower absolute inset-0 h-full w-full fill-charcoal/55 transition-colors group-hover:fill-champagne-dark">
                  <defs>
                    <path id="badge-circle" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
                  </defs>
                  <text fontSize="8" letterSpacing="2.6" fontWeight="700">
                    <textPath href="#badge-circle">YOUR VISION • OUR CREATIVITY • SUNDRA EDITS •</textPath>
                  </text>
                </svg>
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-charcoal/15 bg-cream/70 backdrop-blur transition-all duration-300 group-hover:border-champagne-dark">
                  <ArrowDown className="h-4 w-4 text-charcoal transition-transform duration-300 group-hover:translate-y-0.5" />
                </span>
              </button>
            </motion.div>
          </motion.div>
        </div>

        {/* scroll cue */}
        <motion.div {...fadeProps(1.25)} className="mt-16 hidden items-center gap-4 md:flex">
          <span className="relative h-12 w-px overflow-hidden bg-charcoal/15">
            <motion.span
              className="absolute left-0 top-0 h-5 w-px bg-champagne-dark"
              animate={{ y: [-20, 48] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            />
          </span>
          <span className="text-[10px] font-extrabold uppercase tracking-[0.4em] text-charcoal/50">
            Scroll to explore
          </span>
        </motion.div>
      </motion.div>

      <AnimatePresence>{playing && <VideoModal project={playing} onClose={() => setPlaying(null)} />}</AnimatePresence>
    </section>
  );
}
