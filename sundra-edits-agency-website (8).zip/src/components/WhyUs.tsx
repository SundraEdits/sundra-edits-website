import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { WHY_ITEMS } from "../data/content";
import { scrollToId } from "../lib/scroll";
import { FadeUp, SectionTag, EASE } from "./Reveal";

export default function WhyUs() {
  return (
    <section id="why" className="relative overflow-hidden bg-offwhite py-24 sm:py-32">
      <div className="wrap relative">
        <SectionTag index="05" label="Why Choose Us" />

        <div className="mt-10 flex flex-wrap items-end justify-between gap-8">
          <FadeUp>
            <h2 className="max-w-2xl font-display text-5xl font-black uppercase leading-[0.98] tracking-tight text-charcoal sm:text-6xl lg:text-7xl">
              Why brands choose{" "}
              <span className="text-charcoal/35">Sundra Edits</span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.12}>
            <button
              onClick={() => scrollToId("contact")}
              className="group inline-flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.26em] text-espresso"
              data-hover
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-espresso text-cream transition-all duration-300 group-hover:bg-champagne group-hover:text-charcoal">
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
              </span>
              Start your project
            </button>
          </FadeUp>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_ITEMS.map((item, i) => (
            <motion.article
              key={item.title}
              className="group relative overflow-hidden rounded-3xl border border-charcoal/10 bg-cream p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-champagne/70 hover:shadow-[0_30px_55px_-25px_rgba(154,123,63,0.45)] sm:p-8"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.75, delay: (i % 3) * 0.1, ease: EASE }}
              data-hover
            >
              <span className="pointer-events-none absolute -bottom-8 -right-2 select-none font-display text-[6rem] font-black leading-none text-espresso/[0.045] transition-colors duration-500 group-hover:text-champagne/15">
                0{i + 1}
              </span>
              <span className="relative flex h-[52px] w-[52px] items-center justify-center rounded-2xl bg-espresso text-champagne-light transition-all duration-500 group-hover:rotate-[8deg] group-hover:bg-champagne group-hover:text-charcoal">
                <item.icon className="h-6 w-6" strokeWidth={1.8} />
              </span>
              <h3 className="relative mt-6 font-display text-lg font-extrabold uppercase tracking-[0.03em] text-charcoal">
                {item.title}
              </h3>
              <p className="relative mt-3 text-sm leading-relaxed text-charcoal/65">
                {item.description}
              </p>
              <span className="relative mt-6 block h-[2px] w-10 bg-champagne/60 transition-all duration-500 group-hover:w-full group-hover:bg-gradient-to-r group-hover:from-champagne-dark group-hover:to-champagne-light" />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
