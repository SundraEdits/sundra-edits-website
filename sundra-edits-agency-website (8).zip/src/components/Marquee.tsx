import { Asterisk } from "lucide-react";
import { MARQUEE_ITEMS } from "../data/content";

export default function Marquee() {
  const row = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS];
  return (
    <div className="relative z-10 overflow-hidden border-y border-champagne/25 bg-charcoal py-4 sm:py-5" aria-hidden>
      <div className="animate-marquee flex w-max items-center gap-8 pr-8 hover:[animation-play-state:paused]">
        {[0, 1].map((half) => (
          <div key={half} className="flex items-center gap-8">
            {row.map((item, i) => (
              <span key={`${half}-${i}`} className="flex items-center gap-8">
                <span className="whitespace-nowrap font-display text-lg uppercase tracking-[0.08em] text-cream sm:text-2xl">
                  {item}
                </span>
                <Asterisk className="h-6 w-6 shrink-0 text-champagne" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
