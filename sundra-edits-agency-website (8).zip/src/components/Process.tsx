import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { PROCESS_STEPS } from "../data/content";
import { FadeUp, SectionTag, EASE } from "./Reveal";

export default function Process() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 78%", "end 55%"] });
  const lineX = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });
  const lineY = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  return (
    <section id="process" className="relative overflow-hidden bg-cream py-24 sm:py-32">
      <div className="pointer-events-none absolute -right-40 bottom-0 h-[420px] w-[420px] rounded-full bg-champagne/15 blur-[130px]" aria-hidden />

      <div className="wrap relative">
        <SectionTag index="04" label="Our Process" />

        <div className="mt-10 flex flex-wrap items-end justify-between gap-6">
          <FadeUp>
            <h2 className="font-display font-black uppercase leading-[0.98] tracking-tight text-charcoal">
              <span className="block text-5xl sm:text-6xl lg:text-7xl">Simple process.</span>
              <span className="block text-5xl text-charcoal/35 sm:text-6xl lg:text-7xl">
                Serious craft.
              </span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.15} className="max-w-xs pb-1">
            <p className="font-serif text-2xl italic leading-snug text-espresso">
              Four steps between your idea and a finished experience.
            </p>
          </FadeUp>
        </div>

        <div ref={ref} className="relative mt-16 sm:mt-20">
          <div className="absolute left-0 right-0 top-[9px] hidden h-px bg-charcoal/10 md:block" aria-hidden>
            <motion.div className="h-full origin-left bg-gradient-to-r from-champagne-dark via-champagne to-champagne-light" style={{ scaleX: lineX }} />
          </div>
          <div className="absolute bottom-2 left-[9px] top-2 w-px bg-charcoal/10 md:hidden" aria-hidden>
            <motion.div className="h-full w-full origin-top bg-gradient-to-b from-champagne-dark via-champagne to-champagne-light" style={{ scaleY: lineY }} />
          </div>

          <div className="grid gap-12 pl-10 md:grid-cols-4 md:gap-8 md:pl-0 lg:gap-10">
            {PROCESS_STEPS.map((step, i) => (
              <motion.div
                key={step.title}
                className="group relative"
                initial={{ opacity: 0, y: 44 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.8, delay: i * 0.14, ease: EASE }}
                data-hover
              >
                <span className="absolute -left-10 top-1 flex h-[19px] w-[19px] items-center justify-center md:-left-0 md:top-0">
                  <span className="absolute inset-0 rounded-full border border-champagne-dark/40 transition-all duration-500 group-hover:scale-125 group-hover:border-champagne-dark" />
                  <motion.span
                    className="h-[9px] w-[9px] rounded-full bg-champagne-dark"
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.3 + i * 0.14, ease: EASE }}
                  />
                </span>

                <span className="block font-display text-6xl font-black leading-none text-charcoal/12 transition-all duration-500 group-hover:-translate-y-1.5 group-hover:text-champagne-dark/50 lg:text-7xl">
                  0{i + 1}
                </span>
                <h3 className="mt-5 flex items-center gap-3 font-display text-[1.35rem] font-extrabold uppercase tracking-[0.06em] text-espresso lg:text-2xl">
                  {step.title}
                  <span className="h-px flex-1 bg-charcoal/10 transition-colors duration-500 group-hover:bg-champagne/60 md:hidden lg:block" />
                </h3>
                <p className="mt-3 max-w-xs text-sm leading-relaxed text-charcoal/65">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
