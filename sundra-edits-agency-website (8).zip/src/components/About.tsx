import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Clapperboard, Code2, Share2 } from "lucide-react";
import { ABOUT_IMAGE } from "../data/content";
import { scrollToId } from "../lib/scroll";
import { FadeUp, SectionTag, WordReveal, EASE } from "./Reveal";

const PILLARS = [
  {
    icon: Clapperboard,
    title: "Video & Creative Production",
    text: "Films, reels and advertisements finished to a standard your audience can feel.",
  },
  {
    icon: Share2,
    title: "Social Media Management",
    text: "A consistent, professional presence — planned, published and managed end to end.",
  },
  {
    icon: Code2,
    title: "Website Development",
    text: "Modern digital storefronts that present your products and services beautifully.",
  },
];

export default function About() {
  const imgRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: imgRef, offset: ["start end", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);

  return (
    <section id="about" className="relative overflow-hidden bg-cream py-24 sm:py-32">
      <div className="wrap relative">
        <SectionTag index="01" label="About Sundra Edits" />

        <div className="mt-12 grid gap-14 lg:grid-cols-2 lg:gap-20">
          {/* copy */}
          <div>
            <h2 className="text-4xl font-extrabold leading-[1.08] tracking-tight text-charcoal sm:text-5xl lg:text-[3.4rem]">
              <WordReveal text="Creativity that moves" />{" "}
              <span className="font-serif font-medium italic tracking-normal text-champagne-dark">
                <WordReveal text="brands forward." delay={0.12} />
              </span>
            </h2>

            <FadeUp delay={0.1}>
              <p className="mt-7 max-w-xl text-base leading-relaxed text-charcoal/70 sm:text-lg">
                SUNDRA EDITS is a creative digital service brand focused on helping businesses
                build a stronger online presence. From compelling video content to social media
                management and modern business websites, we transform ideas into professional
                digital experiences.
              </p>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-charcoal/70 sm:text-lg">
                We work as a creative partner to the brands we serve — quietly obsessive about
                quality, and relentlessly focused on how your business is seen, remembered and
                chosen.
              </p>
            </FadeUp>

            <div className="mt-10">
              {PILLARS.map((pillar, i) => (
                <FadeUp key={pillar.title} delay={i * 0.08}>
                  <button
                    onClick={() => scrollToId("services")}
                    className="group flex w-full items-center gap-5 border-t border-charcoal/10 py-5 text-left last:border-b"
                    data-hover
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-espresso text-cream transition-all duration-500 group-hover:rotate-[10deg] group-hover:bg-champagne group-hover:text-charcoal">
                      <pillar.icon className="h-5 w-5" />
                    </span>
                    <span className="flex-1">
                      <span className="block font-display text-base font-bold uppercase tracking-[0.06em] text-charcoal sm:text-lg">
                        {pillar.title}
                      </span>
                      <span className="mt-0.5 block text-sm leading-relaxed text-charcoal/60">
                        {pillar.text}
                      </span>
                    </span>
                    <ArrowRight className="h-5 w-5 shrink-0 text-champagne-dark transition-transform duration-300 group-hover:translate-x-1.5" />
                  </button>
                </FadeUp>
              ))}
            </div>
          </div>

          {/* visual */}
          <div>
            <motion.div
              ref={imgRef}
              className="relative overflow-hidden rounded-[1.4rem] shadow-[0_40px_80px_-30px_rgba(59,47,47,0.5)]"
              initial={{ clipPath: "inset(12% 8% 12% 8% round 24px)", opacity: 0.4 }}
              whileInView={{ clipPath: "inset(0% 0% 0% 0% round 24px)", opacity: 1 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 1.2, ease: EASE }}
            >
              <motion.img
                src={ABOUT_IMAGE}
                alt="The SUNDRA EDITS edit bay — where raw footage becomes story"
                className="h-[320px] w-full scale-[1.18] object-cover sm:h-[420px] lg:h-[500px]"
                style={{ y: imgY }}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/55 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="text-[9px] font-extrabold uppercase tracking-[0.35em] text-champagne-light">
                    Behind the Work
                  </p>
                  <p className="mt-1 font-serif text-2xl italic text-cream">
                    Where raw footage becomes story.
                  </p>
                </div>
              </div>
            </motion.div>

            <FadeUp delay={0.15}>
              <div className="mt-6 flex items-start gap-4 rounded-2xl border border-charcoal/10 bg-offwhite p-6">
                <span className="font-serif text-5xl italic leading-[0.6] text-champagne-dark">“</span>
                <div>
                  <p className="font-serif text-[1.35rem] italic leading-snug text-espresso">
                    Your Vision. Our Creativity. — it isn't a slogan. It's how every project
                    begins and ends.
                  </p>
                  <p className="mt-3 text-[9.5px] font-extrabold uppercase tracking-[0.3em] text-charcoal/50">
                    The Sundra Edits Promise
                  </p>
                </div>
              </div>
            </FadeUp>
          </div>
        </div>
      </div>
    </section>
  );
}
