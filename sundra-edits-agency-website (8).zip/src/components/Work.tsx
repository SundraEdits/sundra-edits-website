import { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ArrowUpRight, Play } from "lucide-react";
import { PROJECTS, type Project } from "../data/content";
import { scrollToId } from "../lib/scroll";
import VideoModal from "./VideoModal";
import { FadeUp, SectionTag, EASE } from "./Reveal";

function PlayButton() {
  return (
    <span className="relative flex h-20 w-20 items-center justify-center sm:h-24 sm:w-24">
      <span className="absolute inset-0 animate-ping rounded-full bg-champagne/35 [animation-duration:2.2s]" />
      <span className="absolute inset-0 rounded-full border border-cream/40 transition-transform duration-700 group-hover:scale-110" />
      <span className="relative flex h-full w-full items-center justify-center rounded-full border border-cream/25 bg-cream/10 text-cream backdrop-blur-md transition-all duration-500 group-hover:scale-105 group-hover:border-champagne group-hover:bg-champagne group-hover:text-charcoal group-hover:shadow-[0_0_50px_rgba(198,161,91,0.55)]">
        <Play className="ml-1 h-7 w-7 fill-current" />
      </span>
    </span>
  );
}

function ProjectCard({
  project,
  flip = false,
  onPlay,
}: {
  project: Project;
  flip?: boolean;
  onPlay: (p: Project) => void;
}) {
  return (
    <motion.article
      className={flip ? "lg:ml-auto lg:w-[88%]" : "lg:w-[88%]"}
      initial={{ opacity: 0, y: 70 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 1, ease: EASE }}
    >
      <button
        onClick={() => onPlay(project)}
        className="group relative block w-full overflow-hidden rounded-[1.4rem] text-left shadow-[0_50px_100px_-40px_rgba(0,0,0,0.85)] ring-1 ring-cream/10 transition-shadow duration-500 hover:ring-champagne/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-champagne"
        aria-label={`Watch the ${project.brand} film`}
        data-hover
      >
        <span className="relative block aspect-[4/3] w-full overflow-hidden sm:aspect-video">
          <motion.span
            className="absolute inset-0 block"
            initial={{ scale: 1.14 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.6, ease: EASE }}
          >
            <img
              src={project.thumbnail}
              alt={`${project.brand} — storefront`}
              className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.07]"
              loading="lazy"
            />
          </motion.span>
          <span className="absolute inset-0 bg-gradient-to-t from-charcoal/85 via-charcoal/10 to-charcoal/30" />
          <span className="absolute inset-0 bg-champagne/0 mix-blend-overlay transition-colors duration-700 group-hover:bg-champagne/15" />

          <span className="absolute inset-x-0 top-0 flex items-start justify-between p-5 sm:p-7">
            <span className="flex items-center gap-2.5 rounded-full border border-cream/25 bg-charcoal/35 py-2 pl-3 pr-4 backdrop-blur-md">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-champagne" />
              <span className="text-[9px] font-extrabold uppercase tracking-[0.3em] text-cream sm:text-[10px]">
                Project {project.index}
              </span>
            </span>
            <span className="hidden items-center gap-2 rounded-full border border-cream/25 bg-charcoal/35 px-4 py-2 text-[9px] font-extrabold uppercase tracking-[0.3em] text-cream backdrop-blur-md sm:flex">
              {project.role}
            </span>
          </span>

          <span className="absolute inset-0 flex flex-col items-center justify-center gap-4">
            <PlayButton />
            <span className="text-[10px] font-extrabold uppercase tracking-[0.45em] text-cream/85 transition-all duration-500 group-hover:tracking-[0.6em] group-hover:text-champagne-light">
              Watch Film
            </span>
          </span>

          <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 sm:p-7">
            <span>
              <span className="block text-[10px] font-extrabold uppercase tracking-[0.32em] text-champagne-light">
                {project.category}
              </span>
              <span className="mt-1.5 block font-display text-3xl font-extrabold uppercase leading-none tracking-[0.01em] text-cream sm:text-5xl">
                {project.brand}
              </span>
            </span>
            <span className="mb-1 hidden h-12 w-12 shrink-0 items-center justify-center rounded-full border border-cream/30 text-cream transition-all duration-500 group-hover:rotate-45 group-hover:border-champagne group-hover:bg-champagne group-hover:text-charcoal md:flex">
              <ArrowUpRight className="h-5 w-5" />
            </span>
          </span>
        </span>
      </button>

      <div className="mt-6 flex flex-wrap items-start justify-between gap-4 border-t border-cream/12 pt-5">
        <p className="max-w-xl text-sm leading-relaxed text-cream/60">{project.description}</p>
        <button
          onClick={() => onPlay(project)}
          className="group/link flex shrink-0 items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.26em] text-cream transition-colors hover:text-champagne-light"
          data-hover
        >
          <Play className="h-3.5 w-3.5 fill-current" />
          Play the film
          <span className="block h-px w-8 bg-current transition-all duration-500 group-hover/link:w-12" />
        </button>
      </div>
    </motion.article>
  );
}

export default function Work() {
  const [active, setActive] = useState<Project | null>(null);
  const close = useCallback(() => setActive(null), []);

  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start end", "end start"] });
  const bgX = useTransform(scrollYProgress, [0, 1], ["2%", "-5%"]);

  return (
    <section
      id="portfolio"
      ref={sectionRef}
      className="grain relative overflow-hidden bg-charcoal py-24 text-cream sm:py-32"
    >
      <div className="pointer-events-none absolute -top-40 left-1/3 h-[480px] w-[480px] rounded-full bg-champagne/10 blur-[150px]" aria-hidden />
      <motion.span
        className="text-stroke-faint pointer-events-none absolute right-0 top-16 select-none whitespace-nowrap font-display text-[19vw] font-black leading-none"
        style={{ x: bgX }}
        aria-hidden
      >
        WORK
      </motion.span>

      <div className="wrap relative">
        <SectionTag index="03" label="Portfolio" dark />

        <div className="mt-10 flex flex-wrap items-end justify-between gap-8">
          <FadeUp>
            <h2 className="font-display font-black uppercase leading-[0.95] tracking-tight">
              <span className="block text-6xl sm:text-7xl lg:text-8xl">Selected</span>
              <span className="text-stroke-cream block text-6xl sm:text-7xl lg:text-8xl">Work</span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.15} className="max-w-sm pb-2">
            <p className="font-serif text-[1.7rem] italic leading-tight text-champagne-light">
              Creative stories. Real visual experiences.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-cream/55">
              Promotional films, brand videos and AI-powered advertisements — press play and step
              inside the work.
            </p>
          </FadeUp>
        </div>

        <div className="mt-16 space-y-20 sm:mt-20 sm:space-y-28">
          {PROJECTS.map((project, i) => (
            <ProjectCard key={project.id} project={project} flip={i % 2 === 1} onPlay={setActive} />
          ))}
        </div>

        <FadeUp className="mt-20 sm:mt-28">
          <div className="flex flex-col items-center gap-5 border-t border-cream/12 pt-12 text-center">
            <p className="font-serif text-2xl italic text-cream/75 sm:text-3xl">
              More stories are in the making —{" "}
              <span className="text-champagne-light">yours could be next.</span>
            </p>
            <button
              onClick={() => scrollToId("contact")}
              className="group relative inline-flex items-center gap-3 overflow-hidden rounded-full border border-cream/25 px-8 py-4 text-[11px] font-extrabold uppercase tracking-[0.24em] text-cream transition-all duration-300 hover:border-champagne hover:text-charcoal"
              data-hover
            >
              <span className="absolute inset-0 -translate-x-[101%] bg-champagne transition-transform duration-500 ease-out group-hover:translate-x-0" />
              <span className="relative">Start Your Story</span>
              <ArrowRight className="relative h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>
        </FadeUp>
      </div>

      <AnimatePresence>{active && <VideoModal project={active} onClose={close} />}</AnimatePresence>
    </section>
  );
}
