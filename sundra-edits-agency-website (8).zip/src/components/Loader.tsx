import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { EASE } from "./Reveal";

const LETTERS = ["S", "U", "N", "D", "R", "A"];

export default function Loader({ onComplete }: { onComplete: () => void }) {
  const [count, setCount] = useState(0);
  const done = useRef(false);

  useEffect(() => {
    const DURATION = 1700;
    const start = performance.now();
    let raf: number;
    const tick = (now: number) => {
      const t = Math.min((now - start) / DURATION, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setCount(Math.round(eased * 100));
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else if (!done.current) {
        done.current = true;
        setTimeout(onComplete, 320);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-[120] flex flex-col justify-between overflow-hidden bg-charcoal text-cream"
      exit={{ y: "-100%" }}
      transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
      aria-hidden
    >
      {/* champagne aura */}
      <div className="pointer-events-none absolute -top-40 right-[-10%] h-[480px] w-[480px] rounded-full bg-champagne/15 blur-[130px]" />
      <div className="pointer-events-none absolute bottom-[-20%] left-[-10%] h-[420px] w-[420px] rounded-full bg-espresso/60 blur-[120px]" />

      {/* top row */}
      <motion.div
        className="relative flex items-center justify-between px-5 pt-6 sm:px-8 lg:px-12"
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-cream/60">
          Creative Agency
        </span>
        <span className="font-serif text-sm italic text-champagne-light">
          Your Vision. Our Creativity.
        </span>
      </motion.div>

      {/* brand lockup */}
      <motion.div
        className="relative px-5 text-center sm:px-8"
        exit={{ opacity: 0, y: -30 }}
        transition={{ duration: 0.35 }}
      >
        <div className="flex items-baseline justify-center overflow-hidden">
          {LETTERS.map((letter, i) => (
            <motion.span
              key={i}
              className="font-display text-[17vw] font-black leading-none tracking-[0.02em] text-cream sm:text-[13vw] lg:text-[9rem]"
              initial={{ y: "115%" }}
              animate={{ y: 0 }}
              transition={{ duration: 0.9, delay: 0.15 + i * 0.07, ease: EASE }}
            >
              {letter}
            </motion.span>
          ))}
        </div>
        <div className="mt-1 flex items-center justify-center gap-4 overflow-hidden">
          <motion.span
            className="h-px w-10 bg-champagne sm:w-16"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.75, ease: EASE }}
          />
          <motion.span
            className="font-display text-[6.5vw] font-black leading-none tracking-[0.42em] text-stroke-champagne sm:text-4xl lg:text-5xl"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.65, ease: EASE }}
          >
            EDITS
          </motion.span>
          <motion.span
            className="h-px w-10 bg-champagne sm:w-16"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.75, ease: EASE }}
          />
        </div>
        <motion.p
          className="mt-6 text-[10px] font-semibold uppercase tracking-[0.5em] text-cream/50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          We create visual impact
        </motion.p>
      </motion.div>

      {/* progress */}
      <motion.div
        className="relative px-5 pb-8 sm:px-8 lg:px-12"
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-4 flex items-end justify-between">
          <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-cream/50">
            Loading Experience
          </span>
          <span className="font-display text-5xl leading-none text-champagne sm:text-6xl">
            {count}
            <span className="text-2xl align-top">%</span>
          </span>
        </div>
        <div className="h-px w-full bg-cream/15">
          <div
            className="h-full bg-gradient-to-r from-champagne-dark via-champagne to-champagne-light transition-[width] duration-100 ease-out"
            style={{ width: `${count}%` }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
