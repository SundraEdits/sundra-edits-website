import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowUp,
  ArrowUpRight,
  CheckCircle2,
  ChevronDown,
  Globe,
  Mail,
  MapPin,
  MessageCircle,
  Send,
} from "lucide-react";
import { CONTACT, ENQUIRY_SERVICES, NAV_LINKS, SOCIALS } from "../data/content";
import { scrollToId, scrollToTop } from "../lib/scroll";
import { BrandIcon } from "./SocialIcons";
import { FadeUp, SectionTag } from "./Reveal";

interface FormState {
  name: string;
  business: string;
  phone: string;
  email: string;
  service: string;
  details: string;
}

const INITIAL: FormState = {
  name: "",
  business: "",
  phone: "",
  email: "",
  service: "Video Editing",
  details: "",
};

export function SocialRow({ dark = false, className = "" }: { dark?: boolean; className?: string }) {
  return (
    <div className={`flex flex-wrap items-center gap-3 ${className}`}>
      {SOCIALS.map((social) => (
        <a
          key={social.label}
          href={social.href}
          target="_blank"
          rel="noreferrer"
          aria-label={`SUNDRA EDITS on ${social.label}`}
          title={social.label}
          className={`group flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 hover:-translate-y-1 hover:border-champagne hover:bg-champagne hover:text-charcoal ${
            dark
              ? "border-cream/20 text-cream/80"
              : "border-charcoal/15 text-charcoal/70 hover:shadow-[0_14px_25px_-10px_rgba(154,123,63,0.6)]"
          }`}
          data-hover
        >
          <BrandIcon name={social.icon} className="h-[17px] w-[17px]" />
        </a>
      ))}
    </div>
  );
}

function EnquiryForm({
  service,
  onServiceChange,
}: {
  service: string;
  onServiceChange: (s: string) => void;
}) {
  const [form, setForm] = useState<FormState>({ ...INITIAL, service });
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [prepared, setPrepared] = useState<string | null>(null);

  const set = (key: keyof FormState, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
    if (key === "service") onServiceChange(value);
  };

  /* keep the dropdown in sync when a service CTA is clicked elsewhere */
  useEffect(() => {
    setForm((f) => (f.service === service ? f : { ...f, service }));
  }, [service]);

  const buildMessage = () => {
    const lines = [
      "Hello SUNDRA EDITS! I would like to enquire about a project.",
      "",
      `Name: ${form.name.trim()}`,
      form.business.trim() ? `Business: ${form.business.trim()}` : null,
      `Phone / WhatsApp: ${form.phone.trim()}`,
      form.email.trim() ? `Email: ${form.email.trim()}` : null,
      `Service Required: ${form.service}`,
      form.details.trim() ? `\nProject Details:\n${form.details.trim()}` : null,
    ].filter(Boolean);
    return lines.join("\n");
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = "Please tell us your name.";
    if (!form.phone.trim() || form.phone.replace(/\D/g, "").length < 8)
      next.phone = "Please add a valid phone / WhatsApp number.";
    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
      next.email = "That email doesn't look quite right.";
    if (!form.service) next.service = "Please choose a service.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    const url = `https://wa.me/919334309446?text=${encodeURIComponent(buildMessage())}`;
    setPrepared(url);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const mailtoUrl = `mailto:${CONTACT.email}?subject=${encodeURIComponent(
    `Project Enquiry — ${form.service} (${form.name || "New Client"})`
  )}&body=${encodeURIComponent(buildMessage())}`;

  const errorCls = (k: keyof FormState) =>
    errors[k] ? "border-red-400 ring-4 ring-red-100" : "";

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="relative overflow-hidden rounded-[1.6rem] border border-charcoal/10 bg-cream p-6 shadow-[0_40px_80px_-40px_rgba(59,47,47,0.4)] sm:p-9"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="font-display text-2xl font-extrabold uppercase tracking-tight text-charcoal">
            Start a Project
          </h3>
          <p className="mt-1.5 text-sm text-charcoal/60">
            Tell us about your project — we'll prepare your enquiry in WhatsApp, ready to send.
          </p>
        </div>
        <span className="hidden h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-champagne/15 text-champagne-dark sm:flex">
          <Send className="h-5 w-5" />
        </span>
      </div>

      <div className="mt-7 grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="f-name" className="field-label">Your Name *</label>
          <input
            id="f-name"
            className={`field ${errorCls("name")}`}
            placeholder="e.g. Priya Sharma"
            value={form.name}
            onChange={(e) => set("name", e.target.value)}
            autoComplete="name"
          />
          {errors.name && <p className="mt-1.5 text-xs font-semibold text-red-500">{errors.name}</p>}
        </div>
        <div>
          <label htmlFor="f-business" className="field-label">Business Name</label>
          <input
            id="f-business"
            className="field"
            placeholder="e.g. Tulip Fashion"
            value={form.business}
            onChange={(e) => set("business", e.target.value)}
            autoComplete="organization"
          />
        </div>
        <div>
          <label htmlFor="f-phone" className="field-label">Phone / WhatsApp *</label>
          <input
            id="f-phone"
            className={`field ${errorCls("phone")}`}
            placeholder="+91 …"
            inputMode="tel"
            value={form.phone}
            onChange={(e) => set("phone", e.target.value)}
            autoComplete="tel"
          />
          {errors.phone && <p className="mt-1.5 text-xs font-semibold text-red-500">{errors.phone}</p>}
        </div>
        <div>
          <label htmlFor="f-email" className="field-label">Email</label>
          <input
            id="f-email"
            type="email"
            className={`field ${errorCls("email")}`}
            placeholder="you@business.com"
            value={form.email}
            onChange={(e) => set("email", e.target.value)}
            autoComplete="email"
          />
          {errors.email && <p className="mt-1.5 text-xs font-semibold text-red-500">{errors.email}</p>}
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="f-service" className="field-label">Service Required *</label>
          <div className="relative">
            <select
              id="f-service"
              className={`field appearance-none pr-12 ${errorCls("service")}`}
              value={form.service}
              onChange={(e) => set("service", e.target.value)}
            >
              {ENQUIRY_SERVICES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-charcoal/40" />
          </div>
          {errors.service && <p className="mt-1.5 text-xs font-semibold text-red-500">{errors.service}</p>}
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="f-details" className="field-label">Project Details</label>
          <textarea
            id="f-details"
            rows={4}
            className="field resize-none"
            placeholder="Tell us about your project — what you need, your timeline, and anything else that helps…"
            value={form.details}
            onChange={(e) => set("details", e.target.value)}
          />
        </div>
      </div>

      <button
        type="submit"
        className="group relative mt-7 flex w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-charcoal px-8 py-4 text-[11px] font-extrabold uppercase tracking-[0.24em] text-cream transition-transform duration-300 hover:scale-[1.015] active:scale-[0.98]"
        data-hover
      >
        <span className="absolute inset-0 -translate-x-[101%] bg-[#25d366] transition-transform duration-500 ease-out group-hover:translate-x-0" />
        <MessageCircle className="relative h-4.5 w-4.5" style={{ height: 18, width: 18 }} />
        <span className="relative">Send Enquiry via WhatsApp</span>
      </button>

      {prepared && (
        <div className="mt-5 flex items-start gap-3 rounded-xl border border-[#25d366]/40 bg-[#25d366]/10 p-4" role="status">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#1da851]" />
          <p className="text-[13px] leading-relaxed text-charcoal/75">
            Your enquiry is ready in WhatsApp — just press <strong>Send</strong> there to complete
            it. If WhatsApp didn't open,{" "}
            <a href={prepared} target="_blank" rel="noreferrer" className="font-bold text-espresso underline underline-offset-2" data-hover>
              tap here to open it
            </a>
            .
          </p>
        </div>
      )}

      <p className="mt-5 text-center text-xs text-charcoal/50">
        Prefer email?{" "}
        <a href={mailtoUrl} className="font-bold text-espresso underline decoration-champagne decoration-2 underline-offset-4 transition-colors hover:text-champagne-dark" data-hover>
          Send this enquiry by email instead
        </a>
      </p>
    </form>
  );
}

export default function Contact({
  service,
  onServiceChange,
}: {
  service: string;
  onServiceChange: (s: string) => void;
}) {
  return (
    <>
      <section id="contact" className="relative overflow-hidden bg-offwhite py-24 sm:py-32">
        <div className="pointer-events-none absolute -right-40 top-0 h-[420px] w-[420px] rounded-full bg-champagne/15 blur-[130px]" aria-hidden />

        <div className="wrap relative">
          <SectionTag index="06" label="Contact — Start a Project" />

          <div className="mt-12 grid gap-14 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
            {/* info column */}
            <div>
              <FadeUp>
                <h2 className="font-display text-5xl font-black uppercase leading-[0.98] tracking-tight text-charcoal sm:text-6xl">
                  Let's create<br />
                  <span className="font-serif font-medium normal-case italic tracking-normal text-champagne-dark">
                    something extraordinary.
                  </span>
                </h2>
                <p className="mt-6 max-w-md text-base leading-relaxed text-charcoal/65">
                  A launch, a campaign, a new website — or a complete transformation of how your
                  brand shows up online. One message is all it takes to begin.
                </p>
              </FadeUp>

              <FadeUp delay={0.1}>
                <div className="mt-9 space-y-4">
                  <a
                    href={CONTACT.whatsappLink}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-center gap-4 rounded-2xl border border-charcoal/10 bg-cream p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-[#25d366]/60 hover:shadow-[0_20px_40px_-20px_rgba(37,211,102,0.5)]"
                    data-hover
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#25d366] text-white">
                      <MessageCircle className="h-5 w-5 fill-current" />
                    </span>
                    <span className="flex-1">
                      <span className="block text-[9.5px] font-extrabold uppercase tracking-[0.3em] text-charcoal/50">
                        WhatsApp — Fastest Reply
                      </span>
                      <span className="mt-0.5 block font-display text-lg font-bold tracking-wide text-charcoal">
                        {CONTACT.whatsappDisplay}
                      </span>
                    </span>
                    <ArrowUpRight className="h-5 w-5 text-charcoal/35 transition-all duration-300 group-hover:rotate-45 group-hover:text-[#1da851]" />
                  </a>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <a
                      href={CONTACT.emailLink}
                      className="group rounded-2xl border border-charcoal/10 bg-cream p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-champagne/70"
                      data-hover
                    >
                      <Mail className="h-5 w-5 text-champagne-dark" />
                      <span className="mt-3 block text-[9.5px] font-extrabold uppercase tracking-[0.3em] text-charcoal/50">Email Us</span>
                      <span className="mt-0.5 block break-all text-sm font-bold text-charcoal">{CONTACT.email}</span>
                    </a>
                    <a
                      href={CONTACT.websiteLink}
                      target="_blank"
                      rel="noreferrer"
                      className="group rounded-2xl border border-charcoal/10 bg-cream p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-champagne/70"
                      data-hover
                    >
                      <Globe className="h-5 w-5 text-champagne-dark" />
                      <span className="mt-3 block text-[9.5px] font-extrabold uppercase tracking-[0.3em] text-charcoal/50">Website</span>
                      <span className="mt-0.5 block text-sm font-bold text-charcoal">{CONTACT.websiteDisplay}</span>
                    </a>
                  </div>

                  <div className="flex items-center gap-4 rounded-2xl border border-charcoal/10 bg-cream p-5">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-espresso text-champagne-light">
                      <MapPin className="h-5 w-5" />
                    </span>
                    <span>
                      <span className="block text-[9.5px] font-extrabold uppercase tracking-[0.3em] text-charcoal/50">
                        Based In
                      </span>
                      <span className="mt-0.5 block text-sm font-bold text-charcoal">{CONTACT.location}</span>
                      <span className="block text-xs text-charcoal/55">Working with brands everywhere.</span>
                    </span>
                  </div>
                </div>
              </FadeUp>

              <FadeUp delay={0.18}>
                <p className="mt-9 text-[10px] font-extrabold uppercase tracking-[0.32em] text-charcoal/50">
                  Follow the journey
                </p>
                <SocialRow className="mt-4" />
              </FadeUp>
            </div>

            {/* form column */}
            <FadeUp delay={0.12}>
              <EnquiryForm key={service} service={service} onServiceChange={onServiceChange} />
            </FadeUp>
          </div>
        </div>
      </section>

      {/* ————————— Footer ————————— */}
      <footer className="grain relative overflow-hidden bg-charcoal text-cream">
        <div className="wrap relative pb-10 pt-16 sm:pt-20">
          <div className="grid gap-12 border-b border-cream/10 pb-14 md:grid-cols-[1.4fr_0.8fr_1fr_1.2fr]">
            <div>
              <button onClick={scrollToTop} className="flex items-baseline gap-2" aria-label="Back to top" data-hover>
                <span className="font-display text-[26px] font-black tracking-[0.03em]">SUNDRA</span>
                <span className="font-display text-[26px] font-black tracking-[0.03em] text-champagne">EDITS</span>
                <span className="text-[9px] font-bold text-cream/50">®</span>
              </button>
              <p className="mt-4 font-serif text-xl italic leading-snug text-cream/70">
                Your Vision. Our Creativity.
              </p>
              <p className="mt-3 max-w-xs text-sm leading-relaxed text-cream/50">
                A creative digital service brand crafting films, advertisements, social presence
                and websites worth remembering.
              </p>
              <SocialRow dark className="mt-6" />
            </div>

            <nav aria-label="Footer">
              <p className="text-[10px] font-extrabold uppercase tracking-[0.35em] text-champagne-light/80">Explore</p>
              <ul className="mt-5 space-y-3">
                {NAV_LINKS.map((link) => (
                  <li key={link.id}>
                    <button
                      onClick={() => scrollToId(link.id)}
                      className="group relative text-sm font-semibold text-cream/70 transition-colors hover:text-cream"
                      data-hover
                    >
                      {link.label}
                      <span className="absolute -bottom-0.5 left-0 h-px w-0 bg-champagne transition-all duration-500 group-hover:w-full" />
                    </button>
                  </li>
                ))}
              </ul>
            </nav>

            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.35em] text-champagne-light/80">Services</p>
              <ul className="mt-5 space-y-3 text-sm font-semibold text-cream/70">
                <li>
                  <button onClick={() => scrollToId("services")} className="transition-colors hover:text-cream" data-hover>
                    Video Editing & Production
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToId("services")} className="transition-colors hover:text-cream" data-hover>
                    AI Advertisement Videos
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToId("services")} className="transition-colors hover:text-cream" data-hover>
                    Social Media Management
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToId("services")} className="transition-colors hover:text-cream" data-hover>
                    Website Development
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.35em] text-champagne-light/80">Get in Touch</p>
              <ul className="mt-5 space-y-3 text-sm font-semibold">
                <li>
                  <a href={CONTACT.whatsappPlain} target="_blank" rel="noreferrer" className="text-cream/70 transition-colors hover:text-champagne-light" data-hover>
                    WhatsApp — {CONTACT.whatsappDisplay}
                  </a>
                </li>
                <li>
                  <a href={CONTACT.emailLink} className="break-all text-cream/70 transition-colors hover:text-champagne-light" data-hover>
                    {CONTACT.email}
                  </a>
                </li>
                <li>
                  <a href={CONTACT.websiteLink} target="_blank" rel="noreferrer" className="text-cream/70 transition-colors hover:text-champagne-light" data-hover>
                    {CONTACT.websiteDisplay}
                  </a>
                </li>
                <li className="flex items-start gap-2 text-cream/70">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-champagne" />
                  {CONTACT.location}
                </li>
              </ul>
              <button
                onClick={scrollToTop}
                className="group mt-7 inline-flex items-center gap-2.5 text-[10px] font-extrabold uppercase tracking-[0.28em] text-cream/60 transition-colors hover:text-cream"
                data-hover
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-cream/20 transition-all duration-300 group-hover:-translate-y-1 group-hover:border-champagne group-hover:bg-champagne group-hover:text-charcoal">
                  <ArrowUp className="h-4 w-4" />
                </span>
                Back to top
              </button>
            </div>
          </div>

          <div className="select-none overflow-hidden pt-10 text-center" aria-hidden>
            <p className="text-stroke-faint whitespace-nowrap font-display text-[11vw] font-black leading-[0.85]">
              SUNDRA EDITS
            </p>
          </div>

          <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-cream/10 pt-7 text-[10px] font-bold uppercase tracking-[0.22em] text-cream/40 sm:flex-row">
            <p>© {new Date().getFullYear()} SUNDRA EDITS — sundraedits.in</p>
            <p className="flex items-center gap-2">
              Your Vision
              <span className="h-1 w-1 rounded-full bg-champagne" />
              Our Creativity
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
