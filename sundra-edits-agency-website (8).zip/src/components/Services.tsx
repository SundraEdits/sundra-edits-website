import { motion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import { SERVICE_DEPARTMENTS } from "../data/content";
import { FadeUp, SectionTag, EASE } from "./Reveal";

export default function Services({
  onEnquire,
}: {
  onEnquire: (service: string) => void;
}) {
  return (
    <section id="services" className="relative overflow-hidden bg-offwhite py-24 sm:py-32">
      <div className="pointer-events-none absolute -left-40 top-0 h-[420px] w-[420px] rounded-full bg-champagne/15 blur-[130px]" aria-hidden />

      <div className="wrap relative">
        <SectionTag index="02" label="Our Services" />

        <div className="mt-10 flex flex-wrap items-end justify-between gap-6">
          <FadeUp>
            <h2 className="font-display font-black uppercase leading-[0.98] tracking-tight text-charcoal">
              <span className="block text-5xl sm:text-6xl lg:text-7xl">Three crafts.</span>
              <span className="block text-5xl text-charcoal/35 sm:text-6xl lg:text-7xl">
                One standard.
              </span>
            </h2>
          </FadeUp>
          <FadeUp delay={0.15} className="max-w-sm pb-1">
            <p className="font-serif text-2xl italic leading-snug text-espresso">
              Everything your brand needs to look world-class — under one roof.
            </p>
          </FadeUp>
        </div>

        <div className="mt-14 space-y-5">
          {SERVICE_DEPARTMENTS.map((dept, i) => (
            <motion.article
              key={dept.index}
              className="group relative overflow-hidden rounded-[1.6rem] border border-charcoal/10 bg-cream transition-all duration-500 hover:border-charcoal/25 hover:shadow-[0_40px_70px_-35px_rgba(59,47,47,0.45)]"
              initial={{ opacity: 0, y: 48 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.85, delay: i * 0.08, ease: EASE }}
            >
              <div className="grid lg:grid-cols-[auto_1fr_1.1fr] lg:gap-12">
                {/* index + icon */}
                <div className="flex items-start gap-5 p-7 pb-0 sm:p-9 sm:pb-0 lg:flex-col lg:gap-8 lg:p-10 lg:pr-0">
                  <span className="font-display text-sm font-black tracking-[0.2em] text-champagne-dark">
                    / {dept.index}
                  </span>
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-espresso text-champagne-light transition-all duration-500 group-hover:rotate-[8deg] group-hover:bg-champagne group-hover:text-charcoal">
                    <dept.icon className="h-6 w-6" strokeWidth={1.8} />
                  </span>
                </div>

                {/* title + positioning */}
                <div className="p-7 pt-5 sm:p-9 sm:pt-6 lg:p-10 lg:pl-0 lg:pt-10">
                  <h3 className="font-display text-[1.65rem] font-extrabold uppercase leading-[1.08] tracking-tight text-charcoal sm:text-3xl lg:text-[2rem]">
                    {dept.title}
                  </h3>
                  <p className="mt-4 max-w-md text-[15px] leading-relaxed text-charcoal/65">
                    {dept.positioning}
                  </p>
                  {dept.note && (
                    <p className="mt-4 inline-block rounded-full bg-champagne/15 px-4 py-2 font-serif text-[15px] italic text-espresso">
                      {dept.note}
                    </p>
                  )}
                  <button
                    onClick={() => onEnquire(dept.enquiryValue)}
                    className="group/btn mt-7 inline-flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-espresso"
                    data-hover
                  >
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-charcoal text-cream transition-all duration-300 group-hover/btn:bg-champagne group-hover/btn:text-charcoal">
                      <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
                    </span>
                    Enquire about this service
                  </button>
                </div>

                {/* included list */}
                <div className="border-t border-charcoal/10 p-7 sm:p-9 lg:border-l lg:border-t-0 lg:p-10">
                  <p className="text-[9.5px] font-extrabold uppercase tracking-[0.32em] text-charcoal/45">
                    What's included
                  </p>
                  <ul className="mt-5 grid gap-x-6 gap-y-3.5 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                    {dept.items.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm font-medium leading-snug text-charcoal/80">
                        <span className="mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full bg-champagne/25 text-champagne-dark" style={{ height: 18, width: 18 }}>
                          <Check className="h-3 w-3" strokeWidth={3} />
                        </span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <span className="absolute inset-x-0 bottom-0 h-[3px] origin-left scale-x-0 bg-gradient-to-r from-champagne-dark via-champagne to-champagne-light transition-transform duration-700 ease-out group-hover:scale-x-100" />
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
